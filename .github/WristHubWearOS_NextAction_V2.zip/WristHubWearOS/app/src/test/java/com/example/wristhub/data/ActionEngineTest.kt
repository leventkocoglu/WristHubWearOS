package com.example.wristhub.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

class ActionEngineTest {
    private val zone = ZoneId.systemDefault()

    @Test
    fun overdueRoutineStaysVisibleUntilHandled() {
        val today = LocalDate.now()
        val now = today.atTime(10, 0).atZone(zone).toInstant().toEpochMilli()
        val routine = Routine("r1", "Test", hour = 9, minute = 30, daysMask = DAYS_EVERY_DAY)

        val next = ActionEngine.nextActions(listOf(routine), now, 1).single()

        assertTrue(next.dueAtMillis < now)
        assertTrue(ActionEngine.relativeLabel(next.dueAtMillis, now).contains("gecikti"))
    }

    @Test
    fun handledRoutineMovesToNextEnabledDay() {
        val today = LocalDate.now()
        val now = today.atTime(10, 0).atZone(zone).toInstant().toEpochMilli()
        val routine = Routine(
            id = "r1",
            title = "Test",
            hour = 9,
            minute = 30,
            daysMask = DAYS_EVERY_DAY,
            lastHandledEpochDay = today.toEpochDay(),
        )

        val next = ActionEngine.nextActions(listOf(routine), now, 1).single()

        assertTrue(next.dueAtMillis > now)
    }

    @Test
    fun snoozeOverridesOriginalDueTime() {
        val today = LocalDate.now()
        val now = today.atTime(10, 0).atZone(zone).toInstant().toEpochMilli()
        val snoozeUntil = now + 10 * 60_000L
        val routine = Routine(
            id = "r1",
            title = "Test",
            hour = 9,
            minute = 30,
            daysMask = DAYS_EVERY_DAY,
            snoozeUntilMillis = snoozeUntil,
        )

        val next = ActionEngine.nextActions(listOf(routine), now, 1).single()

        assertTrue(next.isSnoozed)
        assertEquals(snoozeUntil, next.dueAtMillis)
    }
}
