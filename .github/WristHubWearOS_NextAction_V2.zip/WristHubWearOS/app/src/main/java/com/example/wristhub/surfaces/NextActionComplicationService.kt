package com.example.wristhub.surfaces

import android.app.PendingIntent
import android.content.Intent
import androidx.wear.watchface.complications.data.ComplicationData
import androidx.wear.watchface.complications.data.ComplicationType
import androidx.wear.watchface.complications.data.PlainComplicationText
import androidx.wear.watchface.complications.data.ShortTextComplicationData
import androidx.wear.watchface.complications.datasource.ComplicationRequest
import androidx.wear.watchface.complications.datasource.SuspendingComplicationDataSourceService
import com.example.wristhub.MainActivity
import com.example.wristhub.data.ActionEngine
import com.example.wristhub.data.HubRepository

class NextActionComplicationService : SuspendingComplicationDataSourceService() {
    override suspend fun onComplicationRequest(request: ComplicationRequest): ComplicationData? {
        if (request.complicationType != ComplicationType.SHORT_TEXT) return null
        val state = HubRepository(applicationContext).snapshot()
        val next = ActionEngine.nextActions(state.routines, limit = 1).firstOrNull()
        return buildData(
            text = next?.let { ActionEngine.relativeLabel(it.dueAtMillis, compact = true) } ?: "Temiz",
            title = if (state.privacyMode) "Sıradaki" else next?.routine?.title?.take(12) ?: "WristHub",
        )
    }

    override fun getPreviewData(type: ComplicationType): ComplicationData? =
        if (type == ComplicationType.SHORT_TEXT) buildData("12 dk", "Sıradaki") else null

    private fun buildData(text: String, title: String): ComplicationData {
        val tapAction = PendingIntent.getActivity(
            this,
            7101,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return ShortTextComplicationData.Builder(
            text = PlainComplicationText.Builder(text).build(),
            contentDescription = PlainComplicationText.Builder("Sıradaki eylem: $title, $text").build(),
        )
            .setTitle(PlainComplicationText.Builder(title).build())
            .setTapAction(tapAction)
            .build()
    }
}
