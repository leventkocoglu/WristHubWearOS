package com.example.wristhub.surfaces

import android.content.ComponentName
import androidx.wear.protolayout.TimelineBuilders.Timeline
import androidx.wear.protolayout.material3.MaterialScope
import androidx.wear.protolayout.material3.Typography
import androidx.wear.protolayout.material3.primaryLayout
import androidx.wear.protolayout.material3.text
import androidx.wear.protolayout.material3.textEdgeButton
import androidx.wear.protolayout.modifiers.LayoutModifier
import androidx.wear.protolayout.modifiers.clickable
import androidx.wear.protolayout.modifiers.contentDescription
import androidx.wear.protolayout.ActionBuilders.launchAction
import androidx.wear.protolayout.types.layoutString
import androidx.wear.tiles.Material3TileService
import androidx.wear.tiles.RequestBuilders.TileRequest
import androidx.wear.tiles.TileBuilders.Tile
import com.example.wristhub.MainActivity
import com.example.wristhub.data.ActionEngine
import com.example.wristhub.data.HubRepository

class NextActionTileService : Material3TileService() {
    override suspend fun MaterialScope.tileResponse(requestParams: TileRequest): Tile {
        val state = HubRepository(applicationContext).snapshot()
        val next = ActionEngine.nextActions(state.routines, limit = 1).firstOrNull()
        val openApp = clickable(
            id = "open_wristhub",
            action = launchAction(ComponentName(applicationContext, MainActivity::class.java)),
        )

        val title = when {
            next == null -> "Bugün temiz"
            state.privacyMode -> "Sıradaki eylem"
            else -> next.routine.title
        }
        val whenText = if (next == null) {
            "Yeni rutin eklemek için aç"
        } else {
            ActionEngine.relativeLabel(next.dueAtMillis)
        }

        return Tile.Builder()
            .setFreshnessIntervalMillis(5 * 60_000L)
            .setTileTimeline(
                Timeline.fromLayoutElement(
                    primaryLayout(
                        titleSlot = {
                            text(
                                "WRISTHUB • ŞİMDİ".layoutString,
                                typography = Typography.LABEL_MEDIUM,
                            )
                        },
                        mainSlot = {
                            text(
                                title.layoutString,
                                typography = Typography.TITLE_MEDIUM,
                                maxLines = 3,
                            )
                        },
                        bottomSlot = {
                            textEdgeButton(
                                onClick = openApp,
                                modifier = LayoutModifier.contentDescription("WristHub'u aç"),
                            ) {
                                text(whenText.layoutString)
                            }
                        },
                        onClick = openApp,
                    )
                )
            )
            .build()
    }
}
