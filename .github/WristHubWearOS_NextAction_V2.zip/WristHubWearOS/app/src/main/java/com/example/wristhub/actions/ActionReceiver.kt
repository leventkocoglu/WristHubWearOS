package com.example.wristhub.actions

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.wristhub.data.HubRepository
import com.example.wristhub.notifications.NotificationHelper
import com.example.wristhub.surfaces.SurfaceUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val routineId = intent?.getStringExtra(EXTRA_ROUTINE_ID) ?: return
        val action = intent.action ?: ACTION_SHOW
        val pending = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val appContext = context.applicationContext
                val repository = HubRepository(appContext)
                repository.ensureSeeded()

                when (action) {
                    ACTION_SHOW -> {
                        val dueAt = intent.getLongExtra(EXTRA_DUE_AT, System.currentTimeMillis())
                        val routine = repository.snapshot().routines.firstOrNull { it.id == routineId }
                        if (routine != null && routine.enabled) {
                            repository.markRoutineNotified(routineId, dueAt)
                            NotificationHelper.showRoutineReminder(
                                context = appContext,
                                routine = routine,
                                privacyMode = repository.snapshot().privacyMode,
                            )
                        }
                    }
                    ACTION_DONE -> {
                        repository.completeRoutine(routineId)
                        NotificationHelper.cancelRoutineReminder(appContext, routineId)
                    }
                    ACTION_SNOOZE_10 -> {
                        repository.snoozeRoutine(routineId, 10)
                        NotificationHelper.cancelRoutineReminder(appContext, routineId)
                    }
                    ACTION_SKIP -> {
                        repository.skipRoutine(routineId)
                        NotificationHelper.cancelRoutineReminder(appContext, routineId)
                    }
                }

                ActionScheduler.reschedule(appContext)
                SurfaceUpdater.refresh(appContext)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val ACTION_SHOW = "com.example.wristhub.action.SHOW"
        const val ACTION_DONE = "com.example.wristhub.action.DONE"
        const val ACTION_SNOOZE_10 = "com.example.wristhub.action.SNOOZE_10"
        const val ACTION_SKIP = "com.example.wristhub.action.SKIP"
        const val EXTRA_ROUTINE_ID = "routine_id"
        const val EXTRA_DUE_AT = "due_at"
    }
}
