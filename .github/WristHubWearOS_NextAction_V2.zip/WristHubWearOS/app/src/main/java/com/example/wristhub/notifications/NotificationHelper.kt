package com.example.wristhub.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.wristhub.MainActivity
import com.example.wristhub.R
import com.example.wristhub.actions.ActionReceiver
import com.example.wristhub.data.Routine

object NotificationHelper {
    private const val FOCUS_CHANNEL_ID = "focus_timer"
    private const val ACTION_CHANNEL_ID = "next_action"
    private const val FOCUS_NOTIFICATION_ID = 2401

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    FOCUS_CHANNEL_ID,
                    "Odak zamanlayıcısı",
                    NotificationManager.IMPORTANCE_HIGH,
                ).apply {
                    description = "Odak süresi tamamlandığında uyarır"
                    enableVibration(true)
                }
            )
            manager.createNotificationChannel(
                NotificationChannel(
                    ACTION_CHANNEL_ID,
                    "Sıradaki eylem",
                    NotificationManager.IMPORTANCE_HIGH,
                ).apply {
                    description = "Zamanı gelen rutinleri bilekten hatırlatır"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 120, 80, 180)
                }
            )
        }
    }

    fun showRoutineReminder(context: Context, routine: Routine, privacyMode: Boolean) {
        if (!canNotify(context)) return

        val title = if (privacyMode) "Sıradaki eylem hazır" else routine.title
        val body = if (privacyMode) {
            "Detayı görmek için aç"
        } else {
            routine.note.ifBlank { "Şimdi halledebilir veya kısa süre erteleyebilirsin." }
        }

        val openIntent = PendingIntent.getActivity(
            context,
            routine.id.hashCode(),
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val notification = NotificationCompat.Builder(context, ACTION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_action)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(openIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(if (privacyMode) NotificationCompat.VISIBILITY_PRIVATE else NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "Tamam", actionIntent(context, routine.id, ActionReceiver.ACTION_DONE, 1))
            .addAction(0, "+10 dk", actionIntent(context, routine.id, ActionReceiver.ACTION_SNOOZE_10, 2))
            .addAction(0, "Atla", actionIntent(context, routine.id, ActionReceiver.ACTION_SKIP, 3))
            .build()

        NotificationManagerCompat.from(context).notify(routineNotificationId(routine.id), notification)
    }

    fun cancelRoutineReminder(context: Context, routineId: String) {
        NotificationManagerCompat.from(context).cancel(routineNotificationId(routineId))
    }

    fun showFocusFinished(context: Context) {
        if (!canNotify(context)) return

        val notification = NotificationCompat.Builder(context, FOCUS_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle("Odak tamamlandı")
            .setContentText("Süre bitti. Kısa bir mola verebilirsin.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 250, 100, 250))
            .build()

        NotificationManagerCompat.from(context).notify(FOCUS_NOTIFICATION_ID, notification)
    }

    private fun actionIntent(
        context: Context,
        routineId: String,
        action: String,
        offset: Int,
    ): PendingIntent {
        val intent = Intent(context, ActionReceiver::class.java).apply {
            this.action = action
            putExtra(ActionReceiver.EXTRA_ROUTINE_ID, routineId)
        }
        return PendingIntent.getBroadcast(
            context,
            routineId.hashCode() * 10 + offset,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun routineNotificationId(id: String): Int = 10_000 + (id.hashCode() and 0x0FFF)
}
