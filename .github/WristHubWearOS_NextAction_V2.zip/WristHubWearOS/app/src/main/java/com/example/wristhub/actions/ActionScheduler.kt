package com.example.wristhub.actions

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.wristhub.data.ActionEngine
import com.example.wristhub.data.HubRepository

object ActionScheduler {
    private const val REQUEST_CODE = 3301

    suspend fun reschedule(context: Context) {
        val appContext = context.applicationContext
        val repository = HubRepository(appContext)
        repository.ensureSeeded()
        val next = ActionEngine.nextAlarm(repository.snapshot().routines)
        val alarmManager = appContext.getSystemService(AlarmManager::class.java)
        alarmManager.cancel(pendingIntent(appContext, null, 0L))

        if (next != null) {
            val trigger = next.dueAtMillis.coerceAtLeast(System.currentTimeMillis() + 2_000L)
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                trigger,
                pendingIntent(appContext, next.routine.id, next.dueAtMillis),
            )
        }
    }

    private fun pendingIntent(context: Context, routineId: String?, dueAtMillis: Long): PendingIntent {
        val intent = Intent(context, ActionReceiver::class.java).apply {
            action = ActionReceiver.ACTION_SHOW
            putExtra(ActionReceiver.EXTRA_ROUTINE_ID, routineId)
            putExtra(ActionReceiver.EXTRA_DUE_AT, dueAtMillis)
        }
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
