package com.example.wristhub.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.wear.compose.foundation.lazy.TransformingLazyColumn
import androidx.wear.compose.foundation.lazy.rememberTransformingLazyColumnState
import androidx.wear.compose.material3.AppScaffold
import androidx.wear.compose.material3.Button
import androidx.wear.compose.material3.ButtonDefaults
import androidx.wear.compose.material3.ListHeader
import androidx.wear.compose.material3.MaterialTheme
import androidx.wear.compose.material3.ScreenScaffold
import androidx.wear.compose.material3.Text
import androidx.wear.compose.navigation.SwipeDismissableNavHost
import androidx.wear.compose.navigation.composable
import androidx.wear.compose.navigation.rememberSwipeDismissableNavController
import com.example.wristhub.HubViewModel
import com.example.wristhub.data.ActionEngine
import com.example.wristhub.data.DAYS_EVERY_DAY
import com.example.wristhub.data.DAYS_WEEKDAYS
import com.example.wristhub.data.HubState
import com.example.wristhub.data.Routine
import kotlinx.coroutines.delay
import java.util.Locale

private object Routes {
    const val HOME = "home"
    const val ROUTINES = "routines"
    const val ADD = "add"
    const val EDIT = "edit"
    const val TOOLS = "tools"
    const val FOCUS = "focus"
    const val WATER = "water"
    const val COUNTER = "counter"
    const val SETTINGS = "settings"
}

@Composable
fun WristHubApp(
    requestNotificationPermission: () -> Unit,
    viewModel: HubViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val navController = rememberSwipeDismissableNavController()
    val haptic = LocalHapticFeedback.current
    var selectedRoutineId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { requestNotificationPermission() }

    fun buzz() {
        if (state.hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    MaterialTheme {
        AppScaffold {
            SwipeDismissableNavHost(
                navController = navController,
                startDestination = Routes.HOME,
            ) {
                composable(Routes.HOME) {
                    HomeScreen(
                        state = state,
                        onDone = { id -> buzz(); viewModel.completeAction(id) },
                        onSnooze = { id -> buzz(); viewModel.snoozeAction(id, 10) },
                        onSkip = { id -> buzz(); viewModel.skipAction(id) },
                        onRoutines = { buzz(); navController.navigate(Routes.ROUTINES) },
                        onTools = { buzz(); navController.navigate(Routes.TOOLS) },
                        onSettings = { buzz(); navController.navigate(Routes.SETTINGS) },
                    )
                }
                composable(Routes.ROUTINES) {
                    RoutinesScreen(
                        state = state,
                        onAdd = { buzz(); navController.navigate(Routes.ADD) },
                        onSelect = { id ->
                            selectedRoutineId = id
                            buzz()
                            navController.navigate(Routes.EDIT)
                        },
                    )
                }
                composable(Routes.ADD) {
                    AddRoutineScreen(
                        onTemplate = { id -> buzz(); viewModel.addTemplate(id) },
                        onVoiceRoutine = { title -> buzz(); viewModel.addRoutine(title) },
                    )
                }
                composable(Routes.EDIT) {
                    val routine = state.routines.firstOrNull { it.id == selectedRoutineId }
                    RoutineEditorScreen(
                        routine = routine,
                        onToggle = { id -> buzz(); viewModel.toggleRoutine(id) },
                        onShift = { id, delta -> buzz(); viewModel.shiftRoutine(id, delta) },
                        onDays = { id, days -> buzz(); viewModel.setRoutineDays(id, days) },
                        onDelete = { id ->
                            buzz()
                            viewModel.deleteRoutine(id)
                            navController.popBackStack()
                        },
                    )
                }
                composable(Routes.TOOLS) {
                    ToolsScreen(
                        state = state,
                        onFocus = { buzz(); navController.navigate(Routes.FOCUS) },
                        onWater = { buzz(); navController.navigate(Routes.WATER) },
                        onCounter = { buzz(); navController.navigate(Routes.COUNTER) },
                    )
                }
                composable(Routes.FOCUS) {
                    FocusScreen(
                        state = state,
                        onStart = { seconds -> buzz(); viewModel.startFocus(seconds) },
                        onResume = { buzz(); viewModel.resumeFocus() },
                        onPause = { buzz(); viewModel.pauseFocus() },
                        onReset = { seconds -> buzz(); viewModel.resetFocus(seconds) },
                    )
                }
                composable(Routes.WATER) {
                    WaterScreen(
                        state = state,
                        onAdd = { amount -> buzz(); viewModel.addWater(amount) },
                        onGoal = { goal -> buzz(); viewModel.setWaterGoal(goal) },
                    )
                }
                composable(Routes.COUNTER) {
                    CounterScreen(
                        state = state,
                        onChange = { delta -> buzz(); viewModel.changeCounter(delta) },
                        onReset = { buzz(); viewModel.resetCounter() },
                    )
                }
                composable(Routes.SETTINGS) {
                    SettingsScreen(
                        state = state,
                        onHaptics = { viewModel.setHaptics(it) },
                        onPrivacy = { viewModel.setPrivacyMode(it) },
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    state: HubState,
    onDone: (String) -> Unit,
    onSnooze: (String) -> Unit,
    onSkip: (String) -> Unit,
    onRoutines: () -> Unit,
    onTools: () -> Unit,
    onSettings: () -> Unit,
) {
    val listState = rememberTransformingLazyColumnState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(30_000)
        }
    }
    val actions = ActionEngine.nextActions(state.routines, nowMillis = now, limit = 3)
    val primary = actions.firstOrNull()

    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { ListHeader { Text("WristHub • Şimdi") } }
            item {
                if (primary == null) {
                    ActionOrb(label = "✓", caption = "Bugün temiz")
                } else {
                    ActionOrb(
                        label = ActionEngine.relativeLabel(primary.dueAtMillis, now, compact = true),
                        caption = if (primary.isOverdue(now)) "Bekliyor" else "Sıradaki",
                    )
                }
            }
            item {
                Text(
                    text = if (primary == null) "Yakın eylem kalmadı" else primary.routine.title,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp),
                )
            }
            if (primary != null && primary.routine.note.isNotBlank() && !state.privacyMode) {
                item {
                    Text(
                        text = primary.routine.note,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 18.dp),
                    )
                }
            }
            if (primary != null) {
                item {
                    ActionRow(
                        onDone = { onDone(primary.routine.id) },
                        onSnooze = { onSnooze(primary.routine.id) },
                        onSkip = { onSkip(primary.routine.id) },
                    )
                }
            }
            item {
                Text(
                    text = "Bugün ${state.doneToday} tamamlandı • ${state.skippedToday} atlandı",
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                )
            }
            if (actions.size > 1) {
                item {
                    HubButton(
                        title = "Sonra: ${actions[1].routine.title}",
                        subtitle = ActionEngine.relativeLabel(actions[1].dueAtMillis, now),
                        onClick = onRoutines,
                        variant = true,
                    )
                }
            }
            item { HubButton("Rutinler", "Zamanı ve tekrarını düzenle", onRoutines) }
            item { HubButton("Araçlar", "Odak • Su • Sayaç", onTools, variant = true) }
            item {
                HubButton(
                    "Ayarlar",
                    if (state.privacyMode) "Gizli önizleme açık" else "Gizli önizleme kapalı",
                    onSettings,
                    variant = true,
                )
            }
        }
    }
}

@Composable
private fun RoutinesScreen(
    state: HubState,
    onAdd: () -> Unit,
    onSelect: (String) -> Unit,
) {
    val listState = rememberTransformingLazyColumnState()
    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { ListHeader { Text("Rutinler") } }
            item { HubButton("+ Rutin ekle", "Hazır şablon veya sesle", onAdd) }
            if (state.routines.isEmpty()) {
                item { Text("Henüz rutin yok", style = MaterialTheme.typography.bodyMedium) }
            }
            state.routines.sortedWith(compareBy<Routine> { it.hour }.thenBy { it.minute }).forEach { routine ->
                item {
                    HubButton(
                        title = "${if (routine.enabled) "●" else "○"} ${routine.title}",
                        subtitle = "%02d:%02d • %s".format(
                            routine.hour,
                            routine.minute,
                            dayLabel(routine.daysMask),
                        ),
                        onClick = { onSelect(routine.id) },
                        variant = !routine.enabled,
                    )
                }
            }
        }
    }
}

@Composable
private fun AddRoutineScreen(
    onTemplate: (String) -> Unit,
    onVoiceRoutine: (String) -> Unit,
) {
    val listState = rememberTransformingLazyColumnState()
    var voiceMessage by remember { mutableStateOf("Saate söyle, otomatik eklensin") }
    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
            if (!text.isNullOrBlank()) {
                onVoiceRoutine(text)
                voiceMessage = "Eklendi: $text"
            }
        }
    }

    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { ListHeader { Text("Rutin ekle") } }
            item {
                HubButton(
                    "🎙 Sesle yeni rutin",
                    voiceMessage,
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ne hatırlatayım?")
                        }
                        try {
                            voiceLauncher.launch(intent)
                        } catch (_: ActivityNotFoundException) {
                            voiceMessage = "Sesli giriş bu cihazda yok"
                        }
                    },
                )
            }
            item { Text("Hazır rutinler", style = MaterialTheme.typography.labelMedium) }
            item { HubButton("Toplantıya hazırlan", "Hafta içi • 09:50", { onTemplate("meeting") }, true) }
            item { HubButton("Vardiya kapanışı", "Her gün • 17:30", { onTemplate("shift") }, true) }
            item { HubButton("Çantayı hazırla", "Her gün • 22:00", { onTemplate("bag") }, true) }
            item { HubButton("Kısa hareket molası", "Hafta içi • 15:00", { onTemplate("move") }, true) }
            item { HubButton("Inbox'u kapat", "Hafta içi • 16:30", { onTemplate("inbox") }, true) }
        }
    }
}

@Composable
private fun RoutineEditorScreen(
    routine: Routine?,
    onToggle: (String) -> Unit,
    onShift: (String, Int) -> Unit,
    onDays: (String, Int) -> Unit,
    onDelete: (String) -> Unit,
) {
    val listState = rememberTransformingLazyColumnState()
    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { ListHeader { Text("Rutin") } }
            if (routine == null) {
                item { Text("Rutin bulunamadı") }
            } else {
                item {
                    Text(
                        routine.title,
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 14.dp),
                    )
                }
                item {
                    Text(
                        "%02d:%02d".format(routine.hour, routine.minute),
                        style = MaterialTheme.typography.displayMedium,
                    )
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = { onShift(routine.id, -15) },
                            modifier = Modifier.weight(1f),
                            label = { Text("−15") },
                        )
                        Button(
                            onClick = { onShift(routine.id, 15) },
                            modifier = Modifier.weight(1f),
                            label = { Text("+15") },
                        )
                    }
                }
                item {
                    HubButton(
                        if (routine.enabled) "Aktif" else "Kapalı",
                        "Hatırlatmayı ${if (routine.enabled) "kapat" else "aç"}",
                        { onToggle(routine.id) },
                        variant = !routine.enabled,
                    )
                }
                item {
                    HubButton(
                        "Hafta içi",
                        if (routine.daysMask == DAYS_WEEKDAYS) "Seçili" else "Pzt–Cum",
                        { onDays(routine.id, DAYS_WEEKDAYS) },
                        variant = routine.daysMask != DAYS_WEEKDAYS,
                    )
                }
                item {
                    HubButton(
                        "Her gün",
                        if (routine.daysMask == DAYS_EVERY_DAY) "Seçili" else "Pzt–Paz",
                        { onDays(routine.id, DAYS_EVERY_DAY) },
                        variant = routine.daysMask != DAYS_EVERY_DAY,
                    )
                }
                if (routine.note.isNotBlank()) {
                    item {
                        Text(
                            routine.note,
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp),
                        )
                    }
                }
                item { HubButton("Sil", "Bu rutini kaldır", { onDelete(routine.id) }, true) }
            }
        }
    }
}

@Composable
private fun ToolsScreen(
    state: HubState,
    onFocus: () -> Unit,
    onWater: () -> Unit,
    onCounter: () -> Unit,
) {
    val listState = rememberTransformingLazyColumnState()
    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { ListHeader { Text("Araçlar") } }
            item { HubButton("Odak", formatSeconds(currentRemaining(state)), onFocus) }
            item { HubButton("Su", "${state.waterMl} / ${state.waterGoalMl} ml", onWater, true) }
            item { HubButton("Sayaç", state.counter.toString(), onCounter, true) }
        }
    }
}

@Composable
private fun FocusScreen(
    state: HubState,
    onStart: (Int) -> Unit,
    onResume: () -> Unit,
    onPause: () -> Unit,
    onReset: (Int) -> Unit,
) {
    val listState = rememberTransformingLazyColumnState()
    var selectedMinutes by remember { mutableIntStateOf((state.focusDurationSec / 60).coerceAtLeast(1)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(state.focusEndMillis) {
        while (state.focusEndMillis > System.currentTimeMillis()) {
            now = System.currentTimeMillis()
            delay(250)
        }
        now = System.currentTimeMillis()
    }

    val running = state.focusEndMillis > now
    val remaining = if (running) {
        ((state.focusEndMillis - now + 999) / 1000).toInt().coerceAtLeast(0)
    } else state.focusRemainingSec.coerceAtLeast(0)
    val duration = state.focusDurationSec.coerceAtLeast(1)
    val progress = (remaining.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    val paused = !running && remaining in 1 until duration

    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { ListHeader { Text("Odak") } }
            item { ProgressRing(progress, formatSeconds(remaining)) }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    listOf(15, 25, 45).forEach { minute ->
                        Button(
                            onClick = { selectedMinutes = minute },
                            modifier = Modifier.weight(1f),
                            colors = if (selectedMinutes == minute) ButtonDefaults.buttonColors()
                            else ButtonDefaults.filledVariantButtonColors(),
                            label = { Text("$minute") },
                        )
                    }
                }
            }
            item {
                HubButton(
                    title = when {
                        running -> "Duraklat"
                        paused -> "Devam et"
                        else -> "Başlat"
                    },
                    subtitle = "$selectedMinutes dakika",
                    onClick = {
                        when {
                            running -> onPause()
                            paused -> onResume()
                            else -> onStart(selectedMinutes * 60)
                        }
                    },
                )
            }
            item { HubButton("Sıfırla", "Seçilen süreye dön", { onReset(selectedMinutes * 60) }, true) }
        }
    }
}

@Composable
private fun WaterScreen(
    state: HubState,
    onAdd: (Int) -> Unit,
    onGoal: (Int) -> Unit,
) {
    val listState = rememberTransformingLazyColumnState()
    val progress = state.waterMl.toFloat() / state.waterGoalMl.coerceAtLeast(1).toFloat()
    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { ListHeader { Text("Su") } }
            item { ProgressRing(progress.coerceIn(0f, 1f), "${state.waterMl} ml") }
            item { Text("Hedef ${state.waterGoalMl} ml", style = MaterialTheme.typography.labelMedium) }
            item { HubButton("+250 ml", "Bir bardak", { onAdd(250) }) }
            item { HubButton("+500 ml", "Büyük bardak", { onAdd(500) }, true) }
            item { HubButton("−250 ml", "Yanlış girişi düzelt", { onAdd(-250) }, true) }
            item { HubButton("Hedef +250", "${state.waterGoalMl} ml", { onGoal(state.waterGoalMl + 250) }, true) }
            item { HubButton("Hedef −250", "${state.waterGoalMl} ml", { onGoal(state.waterGoalMl - 250) }, true) }
        }
    }
}

@Composable
private fun CounterScreen(state: HubState, onChange: (Int) -> Unit, onReset: () -> Unit) {
    val listState = rememberTransformingLazyColumnState()
    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { ListHeader { Text("Sayaç") } }
            item { Text(state.counter.toString(), style = MaterialTheme.typography.displayMedium) }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(onClick = { onChange(-1) }, modifier = Modifier.weight(1f), label = { Text("−1") })
                    Button(onClick = { onChange(1) }, modifier = Modifier.weight(1f), label = { Text("+1") })
                }
            }
            item { HubButton("+10", "Hızlı artır", { onChange(10) }, true) }
            item { HubButton("Sıfırla", "Sayacı temizle", onReset, true) }
        }
    }
}

@Composable
private fun SettingsScreen(
    state: HubState,
    onHaptics: (Boolean) -> Unit,
    onPrivacy: (Boolean) -> Unit,
) {
    val listState = rememberTransformingLazyColumnState()
    ScreenScaffold(scrollState = listState) { contentPadding ->
        TransformingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item { ListHeader { Text("Ayarlar") } }
            item {
                HubButton(
                    "Titreşim",
                    if (state.hapticsEnabled) "Açık" else "Kapalı",
                    { onHaptics(!state.hapticsEnabled) },
                )
            }
            item {
                HubButton(
                    "Gizli önizleme",
                    if (state.privacyMode) "Açık • metin bildirimde gizli" else "Kapalı",
                    { onPrivacy(!state.privacyMode) },
                    true,
                )
            }
            item {
                Text(
                    "Veriler cihazda tutulur • hesap gerekmez",
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
            }
            item { Text("WristHub 2.0 • Wear OS", style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun ActionRow(onDone: () -> Unit, onSnooze: () -> Unit, onSkip: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Button(onClick = onDone, modifier = Modifier.weight(1f), label = { Text("✓") })
        Button(
            onClick = onSnooze,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.filledVariantButtonColors(),
            label = { Text("+10") },
        )
        Button(
            onClick = onSkip,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.filledVariantButtonColors(),
            label = { Text("×") },
        )
    }
}

@Composable
private fun ActionOrb(label: String, caption: String) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
    Box(modifier = Modifier.size(128.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 7.dp.toPx()
            val inset = stroke / 2f
            val arcSize = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke)
            drawArc(track, -90f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
            drawArc(primary, -90f, 238f, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(secondary, 158f, 52f, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Text("$label\n$caption", style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
    }
}

@Composable
private fun ProgressRing(progress: Float, centerText: String) {
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.14f)
    Box(modifier = Modifier.size(118.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 8.dp.toPx()
            val inset = stroke / 2f
            val arcSize = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke)
            drawArc(track, -90f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(primary, -90f, 360f * progress.coerceIn(0f, 1f), false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Text(centerText, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
    }
}

@Composable
private fun HubButton(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    variant: Boolean = false,
) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
        colors = if (variant) ButtonDefaults.filledVariantButtonColors() else ButtonDefaults.buttonColors(),
        label = { Text(title) },
        secondaryLabel = { Text(subtitle) },
    )
}

private fun dayLabel(mask: Int): String = when (mask) {
    DAYS_WEEKDAYS -> "Hafta içi"
    DAYS_EVERY_DAY -> "Her gün"
    else -> "Özel günler"
}

private fun currentRemaining(state: HubState): Int =
    if (state.focusEndMillis > System.currentTimeMillis()) {
        ((state.focusEndMillis - System.currentTimeMillis() + 999) / 1000).toInt().coerceAtLeast(0)
    } else state.focusRemainingSec.coerceAtLeast(0)

private fun formatSeconds(totalSeconds: Int): String {
    val safe = totalSeconds.coerceAtLeast(0)
    return "%02d:%02d".format(safe / 60, safe % 60)
}
