package com.example.wristhub.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.wristhub.actions.ActionScheduler
import com.example.wristhub.data.HubRepository
import com.example.wristhub.surfaces.SurfaceUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val appContext = context.applicationContext
                val repository = HubRepository(appContext)
                repository.ensureSeeded()
                val end = repository.getFocusEndMillis()
                if (end > System.currentTimeMillis()) TimerScheduler.schedule(appContext, end)
                ActionScheduler.reschedule(appContext)
                SurfaceUpdater.refresh(appContext)
            } finally {
                pending.finish()
            }
        }
    }
}
