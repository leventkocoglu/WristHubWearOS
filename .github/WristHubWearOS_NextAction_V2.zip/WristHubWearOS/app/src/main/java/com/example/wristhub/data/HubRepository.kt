package com.example.wristhub.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime

private val Context.wristHubDataStore by preferencesDataStore(name = "wrist_hub")

data class HubState(
    val routines: List<Routine> = emptyList(),
    val doneToday: Int = 0,
    val skippedToday: Int = 0,
    val privacyMode: Boolean = false,
    val waterMl: Int = 0,
    val waterGoalMl: Int = 2000,
    val counter: Int = 0,
    val hapticsEnabled: Boolean = true,
    val focusEndMillis: Long = 0L,
    val focusRemainingSec: Int = 25 * 60,
    val focusDurationSec: Int = 25 * 60,
)

class HubRepository(private val context: Context) {

    private object Keys {
        val routinesJson = stringPreferencesKey("routines_json_v2")
        val statsDay = longPreferencesKey("stats_day")
        val doneToday = intPreferencesKey("done_today")
        val skippedToday = intPreferencesKey("skipped_today")
        val privacyMode = booleanPreferencesKey("privacy_mode")
        val waterMl = intPreferencesKey("water_ml")
        val waterGoalMl = intPreferencesKey("water_goal_ml")
        val waterDay = longPreferencesKey("water_day")
        val counter = intPreferencesKey("counter")
        val haptics = booleanPreferencesKey("haptics")
        val focusEnd = longPreferencesKey("focus_end")
        val focusRemaining = intPreferencesKey("focus_remaining")
        val focusDuration = intPreferencesKey("focus_duration")
    }

    private fun today(): Long = LocalDate.now().toEpochDay()

    val state: Flow<HubState> = context.wristHubDataStore.data.map { prefs ->
        val today = today()
        val water = if (prefs[Keys.waterDay] == today) prefs[Keys.waterMl] ?: 0 else 0
        val statsValid = prefs[Keys.statsDay] == today
        val rawRoutines = prefs[Keys.routinesJson]
        val routines = if (rawRoutines.isNullOrBlank()) seedRoutines() else decodeRoutines(rawRoutines)

        HubState(
            routines = routines,
            doneToday = if (statsValid) prefs[Keys.doneToday] ?: 0 else 0,
            skippedToday = if (statsValid) prefs[Keys.skippedToday] ?: 0 else 0,
            privacyMode = prefs[Keys.privacyMode] ?: false,
            waterMl = water,
            waterGoalMl = prefs[Keys.waterGoalMl] ?: 2000,
            counter = prefs[Keys.counter] ?: 0,
            hapticsEnabled = prefs[Keys.haptics] ?: true,
            focusEndMillis = prefs[Keys.focusEnd] ?: 0L,
            focusRemainingSec = prefs[Keys.focusRemaining] ?: 25 * 60,
            focusDurationSec = prefs[Keys.focusDuration] ?: 25 * 60,
        )
    }

    suspend fun ensureSeeded() {
        context.wristHubDataStore.edit { prefs ->
            if (prefs[Keys.routinesJson].isNullOrBlank()) {
                prefs[Keys.routinesJson] = encodeRoutines(seedRoutines())
            }
        }
    }

    suspend fun snapshot(): HubState = state.first()

    suspend fun addRoutine(title: String, note: String = "", hour: Int? = null, minute: Int? = null) {
        mutateRoutines { current ->
            val now = LocalDateTime.now().plusMinutes(30)
            val routine = Routine(
                id = "r${System.currentTimeMillis().toString(36)}",
                title = title.trim().take(50).ifBlank { "Yeni eylem" },
                note = note.trim().take(80),
                hour = hour ?: now.hour,
                minute = minute ?: ((now.minute / 5) * 5),
            )
            current + routine
        }
    }

    suspend fun addTemplate(templateId: String) {
        val template = templateById(templateId) ?: return
        mutateRoutines { current ->
            if (current.any { it.title == template.title }) current else current + template.copy(
                id = "r${System.currentTimeMillis().toString(36)}"
            )
        }
    }

    suspend fun toggleRoutine(id: String) = updateRoutine(id) { it.copy(enabled = !it.enabled) }

    suspend fun shiftRoutine(id: String, minutesDelta: Int) = updateRoutine(id) { routine ->
        val total = (routine.hour * 60 + routine.minute + minutesDelta).floorMod(24 * 60)
        routine.copy(hour = total / 60, minute = total % 60, lastNotifiedAtMillis = 0L)
    }

    suspend fun setRoutineDays(id: String, daysMask: Int) = updateRoutine(id) {
        it.copy(daysMask = daysMask.coerceIn(1, DAYS_EVERY_DAY), lastNotifiedAtMillis = 0L)
    }

    suspend fun deleteRoutine(id: String) = mutateRoutines { it.filterNot { routine -> routine.id == id } }

    suspend fun completeRoutine(id: String) {
        val day = today()
        val routine = snapshot().routines.firstOrNull { it.id == id } ?: return
        if (routine.lastHandledEpochDay == day) return
        updateRoutine(id) {
            it.copy(
                lastHandledEpochDay = day,
                lastResult = "done",
                snoozeUntilMillis = 0L,
            )
        }
        incrementDailyStat(done = true)
    }

    suspend fun skipRoutine(id: String) {
        val day = today()
        val routine = snapshot().routines.firstOrNull { it.id == id } ?: return
        if (routine.lastHandledEpochDay == day) return
        updateRoutine(id) {
            it.copy(
                lastHandledEpochDay = day,
                lastResult = "skip",
                snoozeUntilMillis = 0L,
            )
        }
        incrementDailyStat(done = false)
    }

    suspend fun snoozeRoutine(id: String, minutes: Int) {
        val until = System.currentTimeMillis() + minutes.coerceIn(5, 180) * 60_000L
        updateRoutine(id) {
            it.copy(snoozeUntilMillis = until, lastNotifiedAtMillis = 0L)
        }
    }

    suspend fun markRoutineNotified(id: String, dueAtMillis: Long) = updateRoutine(id) {
        it.copy(lastNotifiedAtMillis = dueAtMillis)
    }

    suspend fun setPrivacyMode(enabled: Boolean) {
        context.wristHubDataStore.edit { it[Keys.privacyMode] = enabled }
    }

    suspend fun addWater(amountMl: Int) {
        context.wristHubDataStore.edit { prefs ->
            val day = today()
            if (prefs[Keys.waterDay] != day) {
                prefs[Keys.waterDay] = day
                prefs[Keys.waterMl] = 0
            }
            prefs[Keys.waterMl] = ((prefs[Keys.waterMl] ?: 0) + amountMl).coerceAtLeast(0)
        }
    }

    suspend fun setWaterGoal(goalMl: Int) {
        context.wristHubDataStore.edit { prefs ->
            prefs[Keys.waterGoalMl] = goalMl.coerceIn(500, 5000)
        }
    }

    suspend fun changeCounter(delta: Int) {
        context.wristHubDataStore.edit { prefs ->
            prefs[Keys.counter] = (prefs[Keys.counter] ?: 0) + delta
        }
    }

    suspend fun resetCounter() {
        context.wristHubDataStore.edit { it[Keys.counter] = 0 }
    }

    suspend fun setHaptics(enabled: Boolean) {
        context.wristHubDataStore.edit { it[Keys.haptics] = enabled }
    }

    suspend fun startFocus(seconds: Int) {
        val safeSeconds = seconds.coerceIn(60, 3 * 60 * 60)
        val end = System.currentTimeMillis() + safeSeconds * 1000L
        context.wristHubDataStore.edit { prefs ->
            prefs[Keys.focusDuration] = safeSeconds
            prefs[Keys.focusRemaining] = safeSeconds
            prefs[Keys.focusEnd] = end
        }
    }

    suspend fun resumeFocus() {
        context.wristHubDataStore.edit { prefs ->
            val remaining = (prefs[Keys.focusRemaining] ?: 25 * 60).coerceAtLeast(1)
            prefs[Keys.focusEnd] = System.currentTimeMillis() + remaining * 1000L
        }
    }

    suspend fun pauseFocus() {
        context.wristHubDataStore.edit { prefs ->
            val end = prefs[Keys.focusEnd] ?: 0L
            val remaining = if (end > 0L) {
                ((end - System.currentTimeMillis()) / 1000L).toInt().coerceAtLeast(0)
            } else {
                prefs[Keys.focusRemaining] ?: 25 * 60
            }
            prefs[Keys.focusRemaining] = remaining
            prefs[Keys.focusEnd] = 0L
        }
    }

    suspend fun resetFocus(seconds: Int = 25 * 60) {
        val safeSeconds = seconds.coerceIn(60, 3 * 60 * 60)
        context.wristHubDataStore.edit { prefs ->
            prefs[Keys.focusDuration] = safeSeconds
            prefs[Keys.focusRemaining] = safeSeconds
            prefs[Keys.focusEnd] = 0L
        }
    }

    suspend fun markFocusFinished() {
        context.wristHubDataStore.edit { prefs ->
            prefs[Keys.focusEnd] = 0L
            prefs[Keys.focusRemaining] = 0
        }
    }

    suspend fun getFocusEndMillis(): Long =
        context.wristHubDataStore.data.first()[Keys.focusEnd] ?: 0L

    private suspend fun incrementDailyStat(done: Boolean) {
        context.wristHubDataStore.edit { prefs ->
            val day = today()
            if (prefs[Keys.statsDay] != day) {
                prefs[Keys.statsDay] = day
                prefs[Keys.doneToday] = 0
                prefs[Keys.skippedToday] = 0
            }
            val key = if (done) Keys.doneToday else Keys.skippedToday
            prefs[key] = (prefs[key] ?: 0) + 1
        }
    }

    private suspend fun updateRoutine(id: String, transform: (Routine) -> Routine) {
        mutateRoutines { list -> list.map { if (it.id == id) transform(it) else it } }
    }

    private suspend fun mutateRoutines(transform: (List<Routine>) -> List<Routine>) {
        context.wristHubDataStore.edit { prefs ->
            val rawRoutines = prefs[Keys.routinesJson]
            val current = if (rawRoutines.isNullOrBlank()) seedRoutines() else decodeRoutines(rawRoutines)
            prefs[Keys.routinesJson] = encodeRoutines(transform(current))
        }
    }

    private fun encodeRoutines(routines: List<Routine>): String {
        val array = JSONArray()
        routines.forEach { r ->
            array.put(JSONObject().apply {
                put("id", r.id)
                put("title", r.title)
                put("note", r.note)
                put("hour", r.hour)
                put("minute", r.minute)
                put("daysMask", r.daysMask)
                put("enabled", r.enabled)
                put("lastHandledEpochDay", r.lastHandledEpochDay)
                put("lastResult", r.lastResult)
                put("snoozeUntilMillis", r.snoozeUntilMillis)
                put("lastNotifiedAtMillis", r.lastNotifiedAtMillis)
            })
        }
        return array.toString()
    }

    private fun decodeRoutines(json: String?): List<Routine> {
        if (json.isNullOrBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(json)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(
                        Routine(
                            id = o.optString("id", "r$i"),
                            title = o.optString("title", "Eylem"),
                            note = o.optString("note", ""),
                            hour = o.optInt("hour", 9).coerceIn(0, 23),
                            minute = o.optInt("minute", 0).coerceIn(0, 59),
                            daysMask = o.optInt("daysMask", DAYS_EVERY_DAY).coerceIn(1, DAYS_EVERY_DAY),
                            enabled = o.optBoolean("enabled", true),
                            lastHandledEpochDay = o.optLong("lastHandledEpochDay", Long.MIN_VALUE),
                            lastResult = o.optString("lastResult", ""),
                            snoozeUntilMillis = o.optLong("snoozeUntilMillis", 0L),
                            lastNotifiedAtMillis = o.optLong("lastNotifiedAtMillis", 0L),
                        )
                    )
                }
            }
        }.getOrElse { emptyList() }
    }


    private fun seedRoutines(): List<Routine> {
        val now = LocalDateTime.now()
        val today = now.toLocalDate()
        return defaultRoutines().map { routine ->
            val dueAlreadyPassed = ActionEngine.isDayEnabled(routine, today) &&
                (routine.hour < now.hour || (routine.hour == now.hour && routine.minute <= now.minute))
            if (dueAlreadyPassed) {
                routine.copy(lastHandledEpochDay = today.toEpochDay(), lastResult = "seed")
            } else {
                routine
            }
        }
    }

    private fun defaultRoutines(): List<Routine> = listOf(
        Routine(
            id = "morning-plan",
            title = "Günün tek önceliğini seç",
            note = "Bugün gerçekten bitmesi gereken tek şeyi belirle.",
            hour = 8,
            minute = 30,
            daysMask = DAYS_WEEKDAYS,
        ),
        Routine(
            id = "midday-reset",
            title = "2 dakikalık reset",
            note = "Sıradaki işi netleştir, gereksiz sekmeleri kapat.",
            hour = 13,
            minute = 30,
            daysMask = DAYS_WEEKDAYS,
        ),
        Routine(
            id = "day-close",
            title = "Günü kapat",
            note = "Açık işi not et ve yarının ilk adımını belirle.",
            hour = 17,
            minute = 45,
            daysMask = DAYS_WEEKDAYS,
        ),
    )

    private fun templateById(id: String): Routine? = when (id) {
        "meeting" -> Routine("meeting", "Toplantıya hazırlan", "Notlarını ve gerekli dosyaları aç.", 9, 50, DAYS_WEEKDAYS)
        "shift" -> Routine("shift", "Vardiya kapanışı", "Anahtar, ekipman ve açık işleri kontrol et.", 17, 30, DAYS_EVERY_DAY)
        "bag" -> Routine("bag", "Çantayı hazırla", "Yarın için gerekenleri tek seferde hazırla.", 22, 0, DAYS_EVERY_DAY)
        "move" -> Routine("move", "Kısa hareket molası", "Ayağa kalk ve iki dakika hareket et.", 15, 0, DAYS_WEEKDAYS)
        "inbox" -> Routine("inbox", "Inbox'u kapat", "Sadece aksiyon gerektirenleri ayır.", 16, 30, DAYS_WEEKDAYS)
        else -> null
    }
}

private fun Int.floorMod(mod: Int): Int = ((this % mod) + mod) % mod
