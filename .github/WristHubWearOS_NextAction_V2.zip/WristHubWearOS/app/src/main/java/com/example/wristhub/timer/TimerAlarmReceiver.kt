package com.example.wristhub.timer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.wristhub.data.HubRepository
import com.example.wristhub.notifications.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TimerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        NotificationHelper.showFocusFinished(context)

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                HubRepository(context.applicationContext).markFocusFinished()
            } finally {
                pending.finish()
            }
        }
    }
}
