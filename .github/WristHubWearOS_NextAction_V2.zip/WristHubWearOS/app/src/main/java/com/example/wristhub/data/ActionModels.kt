package com.example.wristhub.data

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

const val DAYS_EVERY_DAY = 0b1111111
const val DAYS_WEEKDAYS = 0b0011111

data class Routine(
    val id: String,
    val title: String,
    val note: String = "",
    val hour: Int,
    val minute: Int,
    val daysMask: Int = DAYS_EVERY_DAY,
    val enabled: Boolean = true,
    val lastHandledEpochDay: Long = Long.MIN_VALUE,
    val lastResult: String = "",
    val snoozeUntilMillis: Long = 0L,
    val lastNotifiedAtMillis: Long = 0L,
)

data class NextAction(
    val routine: Routine,
    val dueAtMillis: Long,
    val isSnoozed: Boolean = false,
) {
    fun isOverdue(nowMillis: Long = System.currentTimeMillis()): Boolean = dueAtMillis < nowMillis
}

object ActionEngine {
    private val zone: ZoneId get() = ZoneId.systemDefault()

    fun nextActions(
        routines: List<Routine>,
        nowMillis: Long = System.currentTimeMillis(),
        limit: Int = 3,
    ): List<NextAction> = routines
        .asSequence()
        .filter { it.enabled }
        .mapNotNull { nextForRoutine(it, nowMillis) }
        .sortedBy { it.dueAtMillis }
        .take(limit.coerceAtLeast(1))
        .toList()

    fun nextAlarm(
        routines: List<Routine>,
        nowMillis: Long = System.currentTimeMillis(),
    ): NextAction? = routines
        .asSequence()
        .filter { it.enabled }
        .mapNotNull { nextForAlarm(it, nowMillis) }
        .minByOrNull { it.dueAtMillis }

    fun nextForRoutine(routine: Routine, nowMillis: Long): NextAction? {
        if (!routine.enabled) return null
        val now = Instant.ofEpochMilli(nowMillis).atZone(zone)
        val today = now.toLocalDate()
        val todayEpoch = today.toEpochDay()

        if (routine.snoozeUntilMillis > nowMillis) {
            return NextAction(routine, routine.snoozeUntilMillis, isSnoozed = true)
        }

        if (isDayEnabled(routine, today) && routine.lastHandledEpochDay != todayEpoch) {
            val due = today.atTime(routine.hour, routine.minute).atZone(zone).toInstant().toEpochMilli()
            return NextAction(routine, due)
        }

        for (offset in 1..7) {
            val date = today.plusDays(offset.toLong())
            if (isDayEnabled(routine, date)) {
                val due = date.atTime(routine.hour, routine.minute).atZone(zone).toInstant().toEpochMilli()
                return NextAction(routine, due)
            }
        }
        return null
    }

    private fun nextForAlarm(routine: Routine, nowMillis: Long): NextAction? {
        val action = nextForRoutine(routine, nowMillis) ?: return null
        val due = action.dueAtMillis

        // An already-delivered reminder should not immediately schedule itself again.
        // Snoozing creates a new later due time and therefore becomes schedulable again.
        if (routine.lastNotifiedAtMillis >= due && due <= nowMillis) {
            val now = Instant.ofEpochMilli(nowMillis).atZone(zone)
            val today = now.toLocalDate()
            for (offset in 1..7) {
                val date = today.plusDays(offset.toLong())
                if (isDayEnabled(routine, date)) {
                    val futureDue = date.atTime(routine.hour, routine.minute)
                        .atZone(zone).toInstant().toEpochMilli()
                    return NextAction(routine, futureDue)
                }
            }
            return null
        }
        return action
    }

    fun isDayEnabled(routine: Routine, date: LocalDate): Boolean {
        val bit = when (date.dayOfWeek) {
            DayOfWeek.MONDAY -> 0
            DayOfWeek.TUESDAY -> 1
            DayOfWeek.WEDNESDAY -> 2
            DayOfWeek.THURSDAY -> 3
            DayOfWeek.FRIDAY -> 4
            DayOfWeek.SATURDAY -> 5
            DayOfWeek.SUNDAY -> 6
        }
        return routine.daysMask and (1 shl bit) != 0
    }

    fun relativeLabel(
        dueAtMillis: Long,
        nowMillis: Long = System.currentTimeMillis(),
        compact: Boolean = false,
    ): String {
        val delta = dueAtMillis - nowMillis
        val absMinutes = kotlin.math.abs(delta) / 60_000L
        return when {
            delta in -59_999L..59_999L -> "şimdi"
            delta < 0 && absMinutes < 60 -> if (compact) "-$absMinutes dk" else "$absMinutes dk gecikti"
            delta < 0 -> if (compact) "-${absMinutes / 60} sa" else "${absMinutes / 60} sa gecikti"
            absMinutes < 60 -> if (compact) "$absMinutes dk" else "$absMinutes dk kaldı"
            absMinutes < 24 * 60 -> if (compact) "${absMinutes / 60} sa" else "${absMinutes / 60} sa kaldı"
            else -> if (compact) "${absMinutes / (24 * 60)} gün" else "${absMinutes / (24 * 60)} gün kaldı"
        }
    }
}
