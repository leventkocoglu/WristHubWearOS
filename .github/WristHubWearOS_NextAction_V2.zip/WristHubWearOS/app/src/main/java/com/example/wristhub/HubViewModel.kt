package com.example.wristhub

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.wristhub.actions.ActionScheduler
import com.example.wristhub.data.HubRepository
import com.example.wristhub.data.HubState
import com.example.wristhub.surfaces.SurfaceUpdater
import com.example.wristhub.notifications.NotificationHelper
import com.example.wristhub.timer.TimerScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HubViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = HubRepository(application.applicationContext)
    private val appContext get() = getApplication<Application>().applicationContext

    val state = repository.state.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = HubState(),
    )

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
            syncActionSurfaces()
        }
    }

    fun completeAction(id: String) = updateActions {
        repository.completeRoutine(id)
        NotificationHelper.cancelRoutineReminder(appContext, id)
    }
    fun skipAction(id: String) = updateActions {
        repository.skipRoutine(id)
        NotificationHelper.cancelRoutineReminder(appContext, id)
    }
    fun snoozeAction(id: String, minutes: Int) = updateActions {
        repository.snoozeRoutine(id, minutes)
        NotificationHelper.cancelRoutineReminder(appContext, id)
    }
    fun addTemplate(id: String) = updateActions { repository.addTemplate(id) }
    fun addRoutine(title: String) = updateActions { repository.addRoutine(title) }
    fun toggleRoutine(id: String) = updateActions {
        repository.toggleRoutine(id)
        NotificationHelper.cancelRoutineReminder(appContext, id)
    }
    fun shiftRoutine(id: String, minutes: Int) = updateActions {
        repository.shiftRoutine(id, minutes)
        NotificationHelper.cancelRoutineReminder(appContext, id)
    }
    fun setRoutineDays(id: String, daysMask: Int) = updateActions {
        repository.setRoutineDays(id, daysMask)
        NotificationHelper.cancelRoutineReminder(appContext, id)
    }
    fun deleteRoutine(id: String) = updateActions {
        repository.deleteRoutine(id)
        NotificationHelper.cancelRoutineReminder(appContext, id)
    }

    fun setPrivacyMode(enabled: Boolean) = updateActions { repository.setPrivacyMode(enabled) }

    fun addWater(amountMl: Int) = viewModelScope.launch { repository.addWater(amountMl) }
    fun setWaterGoal(goalMl: Int) = viewModelScope.launch { repository.setWaterGoal(goalMl) }
    fun changeCounter(delta: Int) = viewModelScope.launch { repository.changeCounter(delta) }
    fun resetCounter() = viewModelScope.launch { repository.resetCounter() }
    fun setHaptics(enabled: Boolean) = viewModelScope.launch { repository.setHaptics(enabled) }

    fun startFocus(seconds: Int) = viewModelScope.launch {
        repository.startFocus(seconds)
        TimerScheduler.schedule(
            appContext,
            System.currentTimeMillis() + seconds.coerceIn(60, 3 * 60 * 60) * 1000L,
        )
    }

    fun resumeFocus() = viewModelScope.launch {
        repository.resumeFocus()
        val end = repository.getFocusEndMillis()
        if (end > System.currentTimeMillis()) TimerScheduler.schedule(appContext, end)
    }

    fun pauseFocus() = viewModelScope.launch {
        repository.pauseFocus()
        TimerScheduler.cancel(appContext)
    }

    fun resetFocus(seconds: Int = 25 * 60) = viewModelScope.launch {
        repository.resetFocus(seconds)
        TimerScheduler.cancel(appContext)
    }

    private fun updateActions(block: suspend () -> Unit) = viewModelScope.launch {
        block()
        syncActionSurfaces()
    }

    private suspend fun syncActionSurfaces() {
        ActionScheduler.reschedule(appContext)
        SurfaceUpdater.refresh(appContext)
    }
}
