package com.example.wristhub.surfaces

import android.content.ComponentName
import android.content.Context
import androidx.wear.tiles.TileService
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester

object SurfaceUpdater {
    fun refresh(context: Context) {
        val appContext = context.applicationContext
        runCatching {
            TileService.getUpdater(appContext).requestUpdate(NextActionTileService::class.java)
        }
        runCatching {
            ComplicationDataSourceUpdateRequester.create(
                appContext,
                ComponentName(appContext, NextActionComplicationService::class.java),
            ).requestUpdateAll()
        }
    }
}
