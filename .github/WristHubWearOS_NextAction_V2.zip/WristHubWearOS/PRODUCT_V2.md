# WristHub 2.0 ürün notları

## Ürün vaadi

> Telefonu çıkarmadan, şimdi önemli olan tek şeyi gör ve birkaç saniyede hallet.

## Ana akış

1. Sistem zaman ve rutinlerden sıradaki eylemi seçer.
2. Home / Tile / complication aynı eylemi gösterir.
3. Hatırlatma zamanı gelince saat bildirim ve titreşim verir.
4. Kullanıcı Tamam, +10 dk veya Atla seçer.
5. Veri yerelde güncellenir; alarm, Tile ve complication yeniden hesaplanır.

## Bilinçli olarak V2.0'a alınmayanlar

- Bulut hesabı ve backend
- Sürekli GPS / geofence
- Sağlık sensörü tabanlı kararlar
- AI tarafından otomatik karar verme
- Sosyal / takım özellikleri
- Telefon companion ve takvim senkronizasyonu

Bunlar core kullanım döngüsü stabil olmadan eklenmemelidir. V2.1 için en yüksek değerli aday telefon companion + takvim bağlamıdır.

## Test edilmesi gereken ana senaryolar

- Rutin zamanı geldiğinde ekran kapalıyken bildirim
- Bildirimden Tamam / +10 dk / Atla
- +10 dk sonrası ikinci hatırlatma
- Gün değişiminde rutinlerin tekrar kullanılabilir olması
- Saat restart sonrası alarmın tekrar kurulması
- Offline durumda tüm core akış
- Tile'ın eylem sonrası güncellenmesi
- Complication'ın eylem sonrası güncellenmesi
- Gizli önizlemenin üç yüzeyde de metni saklaması
- Yuvarlak ve kare Wear OS emulatorlarında taşma / dokunma alanları
