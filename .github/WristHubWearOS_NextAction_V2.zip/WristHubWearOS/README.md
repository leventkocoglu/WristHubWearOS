# WristHub 2.0 — Wear OS “Sıradaki Eylem”

WristHub 2.0, saatte uzun görev listeleri göstermek yerine **o anda yapılacak tek küçük eylemi** öne çıkaran offline-first Wear OS uygulamasıdır.

## 2.0'da neler değişti?

- Ana ekran artık “Sıradaki Eylem” odaklıdır.
- Eylem doğrudan **Tamam / +10 dk Ertele / Atla** ile yönetilir.
- Rutinler cihazda kalıcı tutulur; hesap veya backend gerekmez.
- Zamanı gelen rutin için yerel bildirim ve haptik uyarı vardır.
- Bildirim üzerinden uygulamayı açmadan Tamam / +10 dk / Atla yapılabilir.
- Wear OS **Tile** eklendi: sıradaki eylem ve kalan süre bir bakışta görünür.
- Saat yüzü için **SHORT_TEXT complication** veri kaynağı eklendi.
- Gizli önizleme modu; bildirim, Tile ve complication üzerinde hassas metni saklayabilir.
- Hazır rutin şablonları eklendi: toplantı hazırlığı, vardiya kapanışı, çanta hazırlığı, hareket molası, inbox kapanışı.
- Saatten sesle yeni rutin ekleme eklendi.
- Rutinler ±15 dk kaydırılabilir, hafta içi / her gün tekrarı seçilebilir, devre dışı bırakılabilir veya silinebilir.
- Günlük tamamlanan / atlanan eylem sayacı vardır.
- Eski Odak, Su ve Sayaç özellikleri korunup ikincil “Araçlar” bölümüne taşındı.
- Yeniden başlatma sonrasında odak alarmı ve sıradaki rutin alarmı tekrar kurulur.

## Tasarım ilkesi

Ana hedef: kullanıcının saate baktıktan sonra karar vermesi değil, **kararı zaten hazır görmesi**. Bu nedenle ana akışta tek eylem, büyük zaman göstergesi ve üç doğrudan aksiyon bulunur. Menü ve yardımcı araçlar aşağı seviyededir.

## Teknik yapı

- Kotlin
- Jetpack Compose for Wear OS Material 3: 1.6.2
- Wear Tiles: 1.6.2
- ProtoLayout / Material 3: 1.4.2
- Wear complication data source: 1.3.0
- DataStore Preferences
- AlarmManager tabanlı event-driven yerel zamanlama
- compileSdk 37 / targetSdk 35 / minSdk 30
- JDK 17
- Gradle 9.6.0 / AGP 9.4.0

## Android Studio'da açma

1. ZIP'i çıkartın.
2. Android Studio > **Open** ile `WristHubWearOS` klasörünü seçin.
3. Settings > Build, Execution, Deployment > Build Tools > Gradle bölümünde **Gradle JDK = 17** seçin.
4. SDK Manager'dan Android API 37 SDK Platform'u kurun.
5. Gradle Sync'i tamamlayın.
6. Wear OS emulator veya gerçek saatinizi seçip **Run**'a basın.

Kotlin daemon bağlantı hatası yaşarsanız `FIX_DAEMON_WINDOWS.md` dosyasındaki ayarlar bu projeye zaten uygulanmıştır.

## Tile'ı ekleme

Saatte Tile düzenleme ekranına girip **WristHub • Sıradaki** Tile'ını ekleyin. Tile, uygulama verisi değiştiğinde push update ister ve ayrıca 5 dakikalık freshness aralığı kullanır.

## Complication ekleme

Complication destekleyen bir watch face'te complication alanını düzenleyip **WristHub • Sıradaki Eylem** veri kaynağını seçin. Kısa metinde kalan süre, başlıkta sıradaki eylem görünür. Gizli önizleme açıksa başlık saklanır.

## Bildirimler

İlk açılışta bildirim izni istenir. Rutin hatırlatmalarının çalışması için bu izni vermek gerekir. İlk kurulum sırasında günün geçmiş saatlerindeki örnek rutinler otomatik “geçmiş” sayılır; uygulama ilk açılışta eski hatırlatmaları art arda göndermez.

## APK / AAB

Debug APK:

`Build > Build Bundle(s) / APK(s) > Build APK(s)`

Tipik çıktı:

`app/build/outputs/apk/debug/app-debug.apk`

Play için:

`Build > Generate Signed App Bundle or APK > Android App Bundle`

## Sonraki ürün katmanı

Bu sürüm watch-first çekirdeği tamamlar. Bir sonraki büyük adım, ayrı Android telefon companion modülü üzerinden takvim izinlerini ve Wear Data Layer senkronizasyonunu eklemektir. Böylece eylem motoru yalnızca saat/rutin bağlamından değil, yaklaşan toplantılardan da otomatik “hazırlık eylemi” üretebilir.
