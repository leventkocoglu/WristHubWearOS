# Kotlin daemon connection fix

This project is configured to compile Kotlin **in-process**, so Android Studio does not need to connect to a separate Kotlin compiler daemon.

## Android Studio
1. File > Settings > Build, Execution, Deployment > Build Tools > Gradle
2. Set **Gradle JDK** to **jbr-17 / JDK 17**.
3. Close Android Studio.
4. In the project folder delete these folders if present:
   - `.gradle`
   - `.kotlin`
   - `app/build`
   - `build`
5. Reopen the project.
6. File > Sync Project with Gradle Files.
7. Build > Clean Project, then Build > Rebuild Project.

## If an old Gradle/Kotlin process is still stuck on Windows
Open PowerShell in the project folder and run:

```powershell
Get-Process java,javaw -ErrorAction SilentlyContinue | Stop-Process -Force
```

Then reopen Android Studio and rebuild.

Do not change Gradle JDK to Java 22 for this project. AGP 9.4 is configured for JDK 17 here.
